import React from 'react'
import { useAppSelector } from '../../app/hooks'

const ProfileData = () => {
  const user = useAppSelector(state => state.user);
  return (
    <div>
      <p>First name: {user!.firstName}</p>
      <p>Last name: {user!.lastName}</p>
      <ul>
        {user!.roles.map(r => <li key={r}>{r}</li>)}
      </ul>
    </div>
  )
}

export default ProfileData