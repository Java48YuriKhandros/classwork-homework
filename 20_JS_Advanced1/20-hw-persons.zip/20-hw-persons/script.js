const persons = [];

//click Add person => add unique person to array persons and add person to
//ordered list id="personsList"

//click Get stats => add after <h2>Stats</h2>: average age, min age, max age