import React from 'react'
import { game } from '../App'

const Result = ({ changePage }) => {
    return (
        <>
            <h1>Lose\Win</h1>
            <h2>1 - 0</h2>
            <button onClick={() => changePage(game)}>Again?</button>
        </>
    )
}

export default Result