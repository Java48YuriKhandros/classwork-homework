import React from 'react'
import { result } from '../App'

const Game = ({ changePage, name }) => {
    return (
        <>
            <h2>Computer</h2>
            <p>Computer card</p>
            <p>Player card</p>
            <h2>{name}</h2>
            <button onClick={() => changePage(result)}>Next</button>
        </>
    )
}

export default Game