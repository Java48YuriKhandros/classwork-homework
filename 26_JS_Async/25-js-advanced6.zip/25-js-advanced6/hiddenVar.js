(function (){
    var x = 3;

})();