import React from 'react'

const Content = () => {
  return (
    <div className='content'>Content</div>
  )
}

export default Content