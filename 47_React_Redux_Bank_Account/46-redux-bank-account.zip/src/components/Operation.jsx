import React, { useState } from 'react'
import { depositAction, withdrawAction } from '../actions/accountActions';
import {store} from '../configureStore/store';

const Operation = () => {

    const [sum, setSum] = useState(1);

    return (
        <div>
            <button onClick={() => store.dispatch(withdrawAction(sum))}>Withdraw</button>
            <input 
                type='number'
                value={sum}
                onChange={e => setSum(+e.target.value)}
            />
            <button onClick={() => store.dispatch(depositAction(sum))}>Deposit</button>
        </div>
    )
}

export default Operation