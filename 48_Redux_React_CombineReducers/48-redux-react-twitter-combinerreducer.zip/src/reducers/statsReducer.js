import { CHANGE_STATS } from "../actions/statsActions";

const initialStats = {
    followers: 0,
    following: 0
}


export const statsReducer = (stats = initialStats, action) => {
    switch (action.type) {
        case CHANGE_STATS:
            const res = stats[action.payload.statsType] + action.payload.sum;
            return { ...stats, [action.payload.statsType]: res >= 0 ? res : 0 }
        default:
            return stats;
    }
}
