import { legacy_createStore } from "@reduxjs/toolkit";
import { rootReducer } from "../reducers/rootReducer";

// const state = {
//     user: {
//         avatar: string",
//         name: "strinf
//     },
//     stats: {
//         followers: number,
//         following: number
//     }
// }

export const store = legacy_createStore(rootReducer);