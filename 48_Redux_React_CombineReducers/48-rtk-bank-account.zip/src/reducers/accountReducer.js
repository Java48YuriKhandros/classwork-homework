import { createReducer } from "@reduxjs/toolkit";
import { depositAction, withdrawAction } from "../actions/accountActions";

const initialState = {
    balance: 0
}

export const accountReducer = createReducer(initialState, {
    [depositAction]: (state, action) => {
        state.balance += action.payload;
    },
    [withdrawAction]: (state, action) => {
        const res = state.balance - action.payload;
        state.balance = res < 0 ? state.balance : res;
    }
})