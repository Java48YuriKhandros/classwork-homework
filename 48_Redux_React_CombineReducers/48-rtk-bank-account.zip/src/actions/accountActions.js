import { createAction } from "@reduxjs/toolkit";

export const depositAction = createAction('DEPOSIT');

export const withdrawAction = createAction('WITHDRAW');