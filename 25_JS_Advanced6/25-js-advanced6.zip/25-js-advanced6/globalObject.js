//var nickName = 'John';
window.nickName = 'John'
console.log(window);
//window.alert('Hello')

console.log(title);
var title = 'JS';

function greeting(){
    console.log('Hello');
}