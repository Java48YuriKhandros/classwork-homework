import React, { useState } from 'react';
import './App.css';
import Footer from './components/Footer';
import Header from './components/Header';
import Main from './components/Main';

const App = () => {

  const [hero, setHero] = useState('luke');

  return (
    <div className="container-fluid">
      <Header hero={hero}/>
      <Main changeHero={setHero}/>
      <Footer />
    </div>
  );

}

export default App;
