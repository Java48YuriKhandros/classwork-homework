import React from 'react'
import UserStats from './UserStats'

const Sidebar = ({user, stats}) => {
    return (
        <div className='sidebar'>
            <UserStats user={user} stats={stats} />
        </div>
    )
}

export default Sidebar