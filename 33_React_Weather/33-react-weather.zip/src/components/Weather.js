import React from 'react'

const Weather = () => {
  return (
    <div className='infoWeath'>
        <p>Location: Il, Rehovot</p>
        <p>Temp: 23</p>
        <p>Pressure: 1000</p>
        <p>Sunset: 18:05</p>
    </div>
  )
}

export default Weather