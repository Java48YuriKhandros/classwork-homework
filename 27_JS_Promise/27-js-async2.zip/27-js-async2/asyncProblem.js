setTimeout(function (url1) {
    const shares = 'List of shares';
    setTimeout(function (url2, shares) {
        const quotes = 'List of quotes';
        setTimeout(function (url3, shares, quotes) {
            const rates = '...........';
        }, 1000)
    }, 1000)
}, 1000)