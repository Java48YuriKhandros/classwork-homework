import { createAction } from "@reduxjs/toolkit";

export const changeName = createAction('CHANGE_NAME');

export const changeAvatar = createAction('CHANGE_AVATAR');
