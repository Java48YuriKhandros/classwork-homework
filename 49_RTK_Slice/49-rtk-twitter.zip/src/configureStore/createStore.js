import { configureStore } from "@reduxjs/toolkit";
import { statsReducer } from "../reducers/statsReducer";
import { userReducer } from "../reducers/userReducer";

// const state = {
//     user: {
//         avatar: string",
//         name: "string
//     },
//     stats: {
//         followers: number,
//         following: number
//     }
// }

export const store = configureStore({
    reducer: {
        user: userReducer,
        stats: statsReducer
    }
});