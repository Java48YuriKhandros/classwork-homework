import { createReducer } from "@reduxjs/toolkit";
import { changeAvatar, changeName } from "../actions/userActions";

const initialState = {
    avatar: "https://www.gravatar.com/avatar/0?d=monsterid",
    name: "Monster"
}

export const userReducer = createReducer(initialState, {
    [changeAvatar]: (state, action ) => {
        state.avatar = action.payload || state.avatar;
    },
    [changeName]: (state, action ) => {
        state.name = action.payload || state.name;
    }
})