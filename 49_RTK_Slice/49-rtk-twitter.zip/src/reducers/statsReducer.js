import { createReducer } from "@reduxjs/toolkit";
import { changeStats } from "../actions/statsActions";

const initialState = {
    followers: 0,
    following: 0
}

export const statsReducer = createReducer(initialState, {
    [changeStats]: (state, action) => {
        const res = state[action.payload.statsType] + action.payload.sum;
        state[action.payload.statsType] = res >= 0 ? res : 0;
    }
})
