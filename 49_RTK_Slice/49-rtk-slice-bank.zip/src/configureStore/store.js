import accountReducer  from "../reducers/accountReducer";
import { configureStore } from "@reduxjs/toolkit";
import { loggerEnhancer } from "../middleware/loggerEnhancer";

export const store = configureStore({
    reducer: {
        account: accountReducer
    },
    middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(loggerEnhancer)
});