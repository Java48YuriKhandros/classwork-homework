import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    avatar: "https://www.gravatar.com/avatar/0?d=monsterid",
    name: "Monster"
}

const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
        changeAvatar: (state, action ) => {
            state.avatar = action.payload || state.avatar;
        },
        changeName: (state, action ) => {
            state.name = action.payload || state.name;
        }
    }
})

export const {changeName, changeAvatar} = userSlice.actions;
export default userSlice.reducer;