import accountReducer  from "../reducers/accountReducer";
import { configureStore } from "@reduxjs/toolkit";
import { loggerEnhancer } from "../middleware/loggerEnhancer";
import quoteReducer from "../reducers/quoteReducer";
import { thunkEnchancer } from "../middleware/thunkEnchancer";

// const state = {
//     account: {
//         balance: Number,
//     },
//     quote: string
// }

export const store = configureStore({
    reducer: {
        account: accountReducer,
        quote: quoteReducer
    },
 //   middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(thunkEnchancer, loggerEnhancer)
});