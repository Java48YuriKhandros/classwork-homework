import { putQuote } from "../reducers/quoteReducer"

export const fetchQuote = () => {
    return (dispatch) => {
        fetch('https://api.gameofthronesquotes.xyz/v1/random')
            .then(response => response.json())
            .then(data => data.sentence)
            .then(quote => dispatch(putQuote(quote)))
            .catch(e => dispatch(putQuote('Error')))
    }
}