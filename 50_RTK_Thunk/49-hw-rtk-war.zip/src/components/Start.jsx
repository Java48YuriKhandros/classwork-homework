import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { game } from '../utils/constants';
import { changeName, changePage } from '../slices/viewSlice';

const Start = () => {

    const dispatch = useDispatch();
    const [name, setName] = useState('');

    const handleClickStart = () => {
        dispatch(changePage(game));
        dispatch(changeName(name));
    }

    return (
        <>
            <h1>Ready For War</h1>
            <input
                onChange={e => setName(e.target.value.toUpperCase())}
                type='text'
                placeholder='Enter your name'
                value={name} />
            <button onClick={handleClickStart}>Start</button>
        </>
    )

}

export default Start