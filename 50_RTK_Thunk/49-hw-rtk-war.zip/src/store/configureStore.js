import { configureStore } from "@reduxjs/toolkit";
import view from '../slices/viewSlice';
import gameWar from '../slices/gameWarSlice';

// const state = {
//     view: {
//         name: string,
//         page: string
//     }, 
//     gameWar: {       
//         globalScore: [number, number, string]
//     }     
// }

export const store = configureStore({
    reducer: {
        view, gameWar
    }
})