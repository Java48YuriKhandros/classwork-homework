import { createSlice } from "@reduxjs/toolkit";

const initialState = {       
    globalScore: [0, 0]
}; 

const gameWarSlice = createSlice({
    name: 'gameWar',
    initialState,
    reducers: {
        draw(state){
            state.globalScore[2] = 'Draw'
        },
        playerWin(state){
            state.globalScore[1]++;
            state.globalScore[2] = 'Win'
        },
        compWin(state){
            state.globalScore[0]++;
            state.globalScore[2] = 'Lose'
        }

    }
})

export const {draw, playerWin, compWin} = gameWarSlice.actions;
export default gameWarSlice.reducer;