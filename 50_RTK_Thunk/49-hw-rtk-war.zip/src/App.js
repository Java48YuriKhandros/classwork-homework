import React from 'react';
import { useSelector } from 'react-redux';
import './App.css';
import Game from './components/Game';
import Result from './components/Result';
import Start from './components/Start';
import { game, result } from './utils/constants';


const App = () => {

  const page = useSelector(state => state.view.page);

  const renderNorm = () => {
    switch (page) {
      case result:
        return <Result />;
      case game:
        return <Game />;
      default:
        return <Start />
    }
  }

  return (
    <div className='App'>
      {renderNorm()}
    </div>
  )

}

export default App;