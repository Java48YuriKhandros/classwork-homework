import React from 'react'

const StarWars = () => {
  return (
    <div>StarWars</div>
  )
}

export default StarWars