import React from 'react'

const AboutMe = () => {
  return (
    <div>AboutMe</div>
  )
}

export default AboutMe