class Group extends React.Component{
    render(){
        return <h3>Java 48</h3>
    }
}

ReactDOM.render(<Group />, document.getElementById('root'));