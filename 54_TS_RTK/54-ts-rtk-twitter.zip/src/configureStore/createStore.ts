import { configureStore } from "@reduxjs/toolkit";
import { useDispatch } from "react-redux";
import { statsReducer } from "../reducers/statsReducer";
import userReducer  from "../reducers/userReducer";

// type State = {
//     user: {
//         avatar: string,
//         name: string
//     },
//     stats: {
//         followers: number,
//         following: number
//     }
// }

export const store = configureStore({
    reducer: {
        user: userReducer,
        stats: statsReducer
    }
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export const useAppDispatch: () => AppDispatch = useDispatch;