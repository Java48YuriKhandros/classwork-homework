import { useSelector } from 'react-redux';
import { RootState, useAppDispatch } from '../configureStore/createStore';
import { changeStats } from '../reducers/statsReducer';
import Avatar from './Avatar';

const UserStats = () => {

  const { user, stats } = useSelector<RootState, RootState>(state => state);
  const dispatch = useAppDispatch();

  return (
    <div className='user-stats'>
      <div>
        <Avatar />
        {user.name}
      </div>
      <div className='stats'>
        <div
          onClick={() => dispatch(changeStats({statsType:'followers', sum: 1}))}
          onContextMenu={e => {
            e.preventDefault();
            dispatch(changeStats({statsType:'followers', sum:-1}));
          }}
        >Followers: {stats.followers}</div>
        <div
          onClick={() => dispatch(changeStats({statsType: 'following', sum: 1}))}
          onContextMenu={e => {
            e.preventDefault();
            dispatch(changeStats({statsType:'following', sum: -1}));
          }}
        >Following: {stats.following}</div>
      </div>
    </div>

  )
}

export default UserStats