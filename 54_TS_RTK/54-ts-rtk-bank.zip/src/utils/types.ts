export interface State {
    account: {
        balance: number,
    },
    quote: string
}
export interface Action {
    type: string,
    payload: any
}
export type Dispatch = (action: Action) => State