import { configureStore } from '@reduxjs/toolkit';
import tokenReducer from '../features/accounting/tokenSlice';
import userReducer from '../features/accounting/userSlice';

export const store = configureStore({
  reducer: {
    token: tokenReducer,
    user: userReducer
  },
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
