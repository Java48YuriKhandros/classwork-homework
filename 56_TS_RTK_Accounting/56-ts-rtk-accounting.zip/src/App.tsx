import './App.css';
import Guest from './components/Guest';
import Profile from './components/Profile';

function App() {
  return (
    <Profile/>
  );
}

export default App;
