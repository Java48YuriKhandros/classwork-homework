import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { fetchUser, registerUser } from "./asyncActions";

const tokenSlice = createSlice({
    name: 'token',
    initialState: null as string | null,
    reducers: {
        putToken: (state, action: PayloadAction<string>) => {
            return action.payload;
        },
        deleteToken: (state) => {
            return null;
        }
    },
    extraReducers: builder => {
        builder
            .addCase(registerUser.fulfilled, (state, action) => {
                return action.payload.token;
            })
            .addCase(fetchUser.fulfilled, (state, action) => {
                return action.payload.token;
            })
    }
})

export const { putToken, deleteToken } = tokenSlice.actions;
export default tokenSlice.reducer;