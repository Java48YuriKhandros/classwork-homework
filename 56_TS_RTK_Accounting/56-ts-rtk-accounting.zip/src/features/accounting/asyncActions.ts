import { createAsyncThunk } from "@reduxjs/toolkit";
import { base_url, createToken } from "../../utils/constants";
import { UserRegister } from "../../utils/types";

export const registerUser = createAsyncThunk(
    'user/register',
    async (user: UserRegister) => {
        const response = await fetch(`${base_url}/user`, {
            method: 'Post',
            body: JSON.stringify(user),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        if (response.ok) {
            const data = await response.json();
            const token = createToken(user.login, user.password);
            return {data, token};
        }
        throw new Error(response.status.toString())
    }
)

export const fetchUser = createAsyncThunk(
    'user/login',
    async (token: string) => {
        const response = await fetch(`${base_url}/login`, {
            method: 'Post',
            headers: {
                Authorization: token
            }
        })
        if (response.ok) {
            const data = await response.json();
            return {data, token};
        }
        throw new Error(response.status.toString())
    }
)