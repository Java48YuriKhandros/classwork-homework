alert('Hello');
const check = confirm('are you older than 18?');
alert(check);
const nickName = prompt("What's your name?");
alert(nickName);