let x = '            Two beer or not two beer             ';
console.log(x);
x = x.trim();
console.log(x);
let res = x.split(' ');
console.log(res);
res = x.toUpperCase();//x.toLowerCase();
console.log(res);