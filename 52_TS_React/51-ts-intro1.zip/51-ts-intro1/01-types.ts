let isLoading: boolean;
isLoading = true;
//isLoading = 0;
isLoading = false;
let num = 42;
//num = 'Hello';
let str: string = 'Hello world!';
console.log(str);
//Array
const primes1: number[] = [2, 3, 5, 7];
const primes2: Array<number> = [11, 13, 17];
primes2.push(19);
console.log(primes1);
primes2.forEach(n => console.log(n));
//Tuple
const john: [string, string, number] = ['John', 'Smith', 123456789];
john[1] = 'Jackson';
john.push(42);
//john.push(true);
john.push('male')
console.log(john);
//Any
let z: any = 100500;
z = 'Hello';
//function typing
function greeting(name: string): void {
    console.log(`Hello ${name}`);
}
greeting('Peter');
//greeting(42);
//Type
type Login = string;
let nickName: Login = 'admin';
type ID = string | number;
const id1: ID = 1234;
const id2: ID = '4321';
type User = {
    email: string,
    password: string,
    birthDate?: Date,
    [key: string]: string | Date | undefined | number
}
const peter: User = {
    email: 'peter@gmail.com',
    password: '1234',
    birthDate: new Date('1999-03-09'),
    hobby: 'chess'
}

const mary: User = {
    email: 'mary@gmail.com',
    password: '4321',
    hobby: 'JS',
    zip: 12345
}

type Area = {
    width: number,
    depth: number,
    area: () => number
}

type Height = {
    height: number
}

type Wardrobe = Area & Height;

const aron: Wardrobe = {
    width: 10,
    depth: 10,
    height: 20,
    area: function() {
        return this.width * this.depth;
    }
}

console.log(aron.area());
