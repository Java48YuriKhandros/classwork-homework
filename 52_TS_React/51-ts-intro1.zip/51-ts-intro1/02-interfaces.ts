interface Address {
    city: string,
    street: string,
    building: number
}

interface Person {
    readonly id: number,
    firstName: string,
    lastName: string,
    address: Address,
    fullName: (greeting: string) => string
}
const john: Person = {
    id: 1,
    firstName: 'John',
    lastName: "Smith",
    address: {
        city: 'Rehovot',
        street: 'Plaut',
        building: 10
    },
    fullName: function (greeting: string) {
        return `${greeting} ${this.firstName} ${this.lastName}`
    }
}

console.log(john.fullName('Mr.'));
console.log(john.id);

//john.id = 10;

const peter = {
    id: 2,
    firstName: 'Peter',
    lastName: "Parker",
    address: {
        city: 'Rehovot',
        street: 'Plaut',
        building: 10
    },
    fullName: function (greeting: string) {
        return `${greeting} ${this.firstName} ${this.lastName}`
    }
}

console.log(peter.fullName('Mr.'));
peter.id = 20;
const peter1 = peter as Person;
//peter1.id = 2;
const peter2 = <Person> peter;
