function pretty(arg: string | number): string | number {
    if (typeof arg === 'number') {
        return arg.toFixed(2);
    } else {
        return arg.trim();
    }
}

class SuccessResponse {
    headers: string[];
    body: string;
}

class ErrorResponse {
    headers: string[];
    code: number;
}

const responseHandler = (response: SuccessResponse | ErrorResponse): { message: number | string } => {
    if (response instanceof SuccessResponse) {
        return { message: response.body };
    } else {
        return { message: response.code };
    }
}

interface MyResponse{
    headers: string[]
}

const response = new SuccessResponse();

const myResponse: MyResponse = new SuccessResponse();

myResponse.headers;
const myResponse1 = myResponse as SuccessResponse;
myResponse1.body
