var john = {
    id: 1,
    firstName: 'John',
    lastName: "Smith",
    address: {
        city: 'Rehovot',
        street: 'Plaut',
        building: 10
    },
    fullName: function (greeting) {
        return greeting + " " + this.firstName + " " + this.lastName;
    }
};
console.log(john.fullName('Mr.'));
console.log(john.id);
//john.id = 10;
var peter = {
    id: 2,
    firstName: 'Peter',
    lastName: "Parker",
    address: {
        city: 'Rehovot',
        street: 'Plaut',
        building: 10
    },
    fullName: function (greeting) {
        return greeting + " " + this.firstName + " " + this.lastName;
    }
};
console.log(peter.fullName('Mr.'));
peter.id = 20;
var peter1 = peter;
//peter1.id = 2;
var peter2 = peter;
