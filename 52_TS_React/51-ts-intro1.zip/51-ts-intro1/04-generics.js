var arr1 = [2, 3, 5, 7];
var arr2 = ['one', 'two', 'three'];
// function reverseArrayNumber(arr: number[]): number[]{
//     return arr.reverse();
// }
// function reverseArrayString(arr: string[]): string[]{
//     return arr.reverse();
// }
// console.log(reverseArrayNumber(arr1));
// console.log(reverseArrayString(arr2));
function reverseArray(arr) {
    return arr.reverse();
}
console.log(reverseArray(arr1));
console.log(reverseArray(arr2));
