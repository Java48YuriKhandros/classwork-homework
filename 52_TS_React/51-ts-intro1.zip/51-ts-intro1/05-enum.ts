// enum UserAction{
//     CHANGE_PASSWORD, UPDATE_PROFILE, ADD_ROLE
// }

// let userAction = UserAction.UPDATE_PROFILE;
// console.log(userAction);
// //userAction = 'ADD_ROLE';
// userAction = UserAction.ADD_ROLE;
// console.log(userAction);
// let value = UserAction[0];
// console.log(value);

enum UserAction{
    CHANGE_PASSWORD = 'changePassword', UPDATE_PROFILE = 'updateProfile', ADD_ROLE = 'addRole'
}
let userAction = UserAction.UPDATE_PROFILE;
console.log(userAction);