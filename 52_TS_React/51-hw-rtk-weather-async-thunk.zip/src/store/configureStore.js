import { configureStore } from "@reduxjs/toolkit";
import messageReducer from "../slices/messageSlice";
import weatherReducer from "../slices/weatherSlice";

// state = {
//     weatherInfo: {
//         [key]: string|number
//     },
//     message: string
// }

export const store = configureStore({
    reducer: {
        weatherInfo: weatherReducer,
        message: messageReducer
    }
})