import { createAsyncThunk } from "@reduxjs/toolkit";
import { api_key, base_url } from "../utils/constants";


export const fetchWeather = createAsyncThunk(
    'weather/fetchWeather',
    async city => {
        const response = await fetch(`${base_url}?q=${city}&appid=${api_key}&units=metric`);
        if (response.ok) {
            const data = await response.json();
            return data;
        }else {
            throw new Error();
        }

    }
) 