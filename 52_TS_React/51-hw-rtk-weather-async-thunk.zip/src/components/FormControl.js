import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { fetchWeather } from '../actions/actionFunctions';

export const FormControl = () => {

    const [city, setCity] = useState('');
    const dispatch = useDispatch();

    const handleChangeCity = e => {
        setCity(e.target.value)
    }

    const handleClickGetWeather = () => {
        dispatch(fetchWeather(city));
        setCity('');
    }

    return (
        <div>
            <input onChange={handleChangeCity} type='text' value={city} />
            <button onClick={handleClickGetWeather} >Get weather</button>
        </div>
    )

}

export default FormControl