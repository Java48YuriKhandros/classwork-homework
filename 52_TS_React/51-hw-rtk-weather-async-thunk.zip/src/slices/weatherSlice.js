import { createSlice } from "@reduxjs/toolkit";
import { fetchWeather } from '../actions/actionFunctions';

const weatherSlice = createSlice({
    name: 'weather',
    initialState: {},
    reducer: {},
    extraReducers: {
        [fetchWeather.fulfilled]: (state, action) => {
            const data = action.payload;
            state.country = data.sys.country;
            state.city = data.name;
            state.temp = data.main.temp;
            state.pressure = data.main.pressure;
            state.sunset = data.sys.sunset;
        }
    }
})


export const { putInfo } = weatherSlice.actions;
export default weatherSlice.reducer;