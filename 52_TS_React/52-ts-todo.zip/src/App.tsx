import React from 'react';
import Task from './components/Task';
import './App.css';

interface State{
  tasks: string[]
}

class App extends React.Component<any, State> {
  constructor(props: any) {
      super(props);
      this.state = {
          tasks: []
      }
  }

  deleteTask = (index: number) => {
      const tasks = [...this.state.tasks];
      tasks.splice(index, 1);
      const obj = {
          tasks: tasks
      }
      this.setState(obj);
  }

  updateTask = (index: number, content: string) => {
      const tasks = [...this.state.tasks];
      tasks[index] = content;
      this.setState({ tasks });
  }

  handleClickAddNewTask = () => {
      const tasks = [...this.state.tasks, 'New Task'];
      this.setState({ tasks });
  }

  render() {
      return (
          <div className="field">
              <button className='btn new' onClick={this.handleClickAddNewTask}>Add Task</button>
              {this.state.tasks.map((t, i) => <Task 
                                                  key={i + 1} 
                                                  index={i} 
                                                  editTask={this.updateTask} 
                                                  deleteTask={this.deleteTask}
                                                  content={t}
                                                />
                                              )}
          </div>
      )
  }
}

export default App;
