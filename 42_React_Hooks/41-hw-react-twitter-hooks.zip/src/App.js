import React, { useState } from 'react'
import './App.css'
import Body from './components/Body'
import Nav from './components/Nav'
import { TwitterContext } from './utils/context'

const App = () => {

  const [user, setUser] = useState({
    avatar: "https://www.gravatar.com/avatar/0?d=monsterid",
    name: "Monster"
  })

  const [stats, setStats] = useState({
    followers: 1000,
    following: 100
  })

  const changeAvatar = url => {
    setUser(user => ({...user, avatar: url || user.avatar}));
  }

  return (
    <div className='app'>
      <TwitterContext.Provider value={{
        user, stats, changeAvatar
      }}>
        <Nav />
        <Body />
      </TwitterContext.Provider>
    </div>
  )

}

export default App;