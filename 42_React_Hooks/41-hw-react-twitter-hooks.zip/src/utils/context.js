import React from "react";

export const TwitterContext = React.createContext();