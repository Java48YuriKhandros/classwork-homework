import { accountReducer } from "../reducers/accountReducer";
import Store from "../redux/Store";

const initialState = {
    balance: 0
}

export const store = new Store(accountReducer, initialState);