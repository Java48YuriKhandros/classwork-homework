var isLoading;
isLoading = true;
//isLoading = 0;
isLoading = false;
var num = 42;
//num = 'Hello';
var str = 'Hello world!';
console.log(str);
//Array
var primes1 = [2, 3, 5, 7];
var primes2 = [11, 13, 17];
primes2.push(19);
console.log(primes1);
primes2.forEach(function (n) { return console.log(n); });
//Tuple
var john = ['John', 'Smith', 123456789];
john[1] = 'Jackson';
john.push(42);
//john.push(true);
john.push('male');
console.log(john);
//Any
var z = 100500;
z = 'Hello';
//function typing
function greeting(name) {
    console.log("Hello " + name);
}
greeting('Peter');
//greeting(42);
