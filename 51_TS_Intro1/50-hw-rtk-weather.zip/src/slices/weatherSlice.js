import { createSlice } from "@reduxjs/toolkit";

// const weatherSlice = createSlice({
//     name: 'weather',
//     initialState: {},
//     reducers: {
//         putInfo(state, action) {
//             const data = action.payload;
//             state.country = data.sys.country;
//             state.city = data.name;
//             state.temp = data.main.temp;
//             state.pressure = data.main.pressure;
//             state.sunset = data.sys.sunset;
//         }
//     }
// })

const weatherSlice = createSlice({
    name: 'weather',
    initialState: {},
    reducers: {
        putInfo(state, action) {
            return action.payload;
        }
    }
})

export const {putInfo} = weatherSlice.actions;
export default weatherSlice.reducer;