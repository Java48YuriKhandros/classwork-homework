import { clear, error, pending } from "../slices/messageSlice";
import { putInfo } from "../slices/weatherSlice";
import { api_key, base_url } from "../utils/constants";


// export const fetchWeather = city => {
//     return async (dispatch) => {
//         try {
//             dispatch(pending())
//             const response = await fetch(`${base_url}?q=${city}&appid=${api_key}&units=metric`);
//             const data = await response.json();
//             dispatch(putInfo(data))
//             dispatch(clear())
//         } catch (e) {
//             dispatch(error())
//         }
//     }
// }

export const fetchWeather = city => {
    return dispatch => {
        dispatch(pending())
        fetch(`${base_url}?q=${city}&appid=${api_key}&units=metric`)
            .then(response => response.json())
            .then(data => {
                const info = {
                    country: data.sys.country,
                    city: data.name,
                    temp: data.main.temp,
                    pressure: data.main.pressure,
                    sunset: data.sys.sunset
                }
                return info;
            })
            .then(info => {
                dispatch(putInfo(info))
                dispatch(clear())
            })
            .catch(e => dispatch(error()))


    }
}