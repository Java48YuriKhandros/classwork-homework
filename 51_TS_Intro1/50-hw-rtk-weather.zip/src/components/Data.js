import React from 'react'
import Form from './FormControl'
import Weather from './Weather'

const Data = () => {

    return (
        <div>
            <Form />
            <Weather />
        </div>
    )

}

export default Data