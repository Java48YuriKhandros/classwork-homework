let x = 10;
let y = 5;
let res = add(x, y);
console.log(`res = ${res}`);

function add(a, b){
    let res = a + b;
    return res;
}