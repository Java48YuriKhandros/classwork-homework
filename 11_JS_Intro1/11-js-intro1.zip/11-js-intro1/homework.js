let res = sumDigits(1234);
console.log(`res = ${res}`); // res = 10
res = luckyNumber(123871); // 1 + 3 + 7 === 2 + 8 + 1
console.log(res ? 'lucky' : 'unlucky');

function sumDigits(num){
    // TODO
}

function luckyNumber(num){
    // TODO
}