const primes = [2, 3, 5, 7, 11, 13, 17, 19];
printArray(primes);
reverseArray(primes);
printArray(primes); //19,17,13,11,7,5,3,2
let index = search(primes, 13);
console.log(index); //2
index = search(primes, 1);
console.log(index); //-1

function printArray(arr) {
    // TODO
}

function reverseArray(arr) {
    // TODO
}

function search(arr, value) {
    // TODO
}

