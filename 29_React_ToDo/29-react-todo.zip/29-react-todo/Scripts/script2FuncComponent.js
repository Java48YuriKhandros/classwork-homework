const Group = () => {
    return <h2>Java 48</h2>
}

ReactDOM.render(<Group />, document.getElementById('root'));