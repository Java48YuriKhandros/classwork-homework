red.onclick = function(e){
    console.log('red', e.currentTarget, e.target);
}

green.onclick = function(e){
    console.log('green',e.currentTarget, e.target);
}

blue.onclick = function(e){
    console.log('blue', e.currentTarget, e.target);
}