//console.log(window);
//window.alert('Hello');
//open('https://www.tel-ran.com/');
console.log(navigator.userAgent);
console.log(navigator.userAgentData.platform);
console.log(location.origin);