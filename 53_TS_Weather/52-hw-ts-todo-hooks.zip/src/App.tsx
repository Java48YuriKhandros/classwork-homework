import React, { useState } from 'react';
import Task from './components/Task';
import './App.css';


const App = () => {

    const [tasks, setTasks] = useState<string[]>([])

    const deleteTask = (index: number) => {
        const arr = [...tasks];
        arr.splice(index, 1);
        setTasks(arr);
    }

    const updateTask = (index: number, content: string) => {
        const arr = [...tasks];
        arr[index] = content;
        setTasks(arr)
    }

    const handleClickAddNewTask = () => {
        const arr = [...tasks, 'New Task'];
        setTasks(arr)
    }


    return (
        <div className="field">
            <button className='btn new' onClick={handleClickAddNewTask}>Add Task</button>
            {tasks.map((t, i) => <Task
                key={i + 1}
                index={i}
                editTask={updateTask}
                deleteTask={deleteTask}
                content={t}
            />
            )}
        </div>
    )

}

export default App;
