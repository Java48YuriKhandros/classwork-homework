import React, { useRef, useState } from "react";

interface Props {
    index: number,
    editTask: (index: number, content: string) => void,
    deleteTask: (index: number) => void,
    content: string
}

const Task = ({ index, editTask, deleteTask, content }: Props) => {
    const textId = useRef<HTMLTextAreaElement>(null);
    const [isEdit, setIsEdit] = useState<boolean>(false);


    const handleClickEdit = () => {
        setIsEdit(true);
    }

    const handleClickRemove = () => {
        deleteTask(index);
    }

    const handleClickSave = () => {
        const task = textId.current!.value;
        editTask(index, task);
        setIsEdit(false);
    }

    const renderEdit = () => {
        return (
            <div className="box">
                <textarea ref={textId} defaultValue={content}></textarea>
                <button onClick={handleClickSave} className="btn success">Save</button>
            </div>
        )
    }

    const renderView = () => {
        return (
            <div className="box">
                <div>{content}</div>
                <button onClick={handleClickEdit} className="btn light">Edit</button>
                <button onClick={handleClickRemove} className="btn red">Remove</button>
            </div>
        )
    }

    return isEdit ? renderEdit() : renderView();
}

export default Task;