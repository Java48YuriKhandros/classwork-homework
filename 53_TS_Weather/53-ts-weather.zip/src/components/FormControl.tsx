import { ChangeEvent, useState } from 'react';

interface Props {
    getWeather: (city: string) => void
}

const FormControl = ({ getWeather }: Props) => {

    const [city, setCity] = useState('');

    const handleChangeCity = (e: ChangeEvent<HTMLInputElement>) => {
        setCity(e.target.value);
    }

    const handleClickGetWeather = () => {
        getWeather(city);
        setCity('');
    }


    return (
        <div>
            <input onChange={handleChangeCity} type='text' value={city} />
            <button onClick={handleClickGetWeather} >Get weather</button>
        </div>
    )

}

export default FormControl