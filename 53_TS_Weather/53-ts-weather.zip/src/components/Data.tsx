import React, { useState } from 'react'
import { api_key, base_url } from '../utils/constants'
import { WeatherInfo } from '../utils/types'
import Form from './FormControl'
import Weather from './Weather'

const Data = () => {

    const [weatherInfo, setWeatherInfo] = useState<WeatherInfo>({});
    const [message, setMessage] = useState('Enter city name');

    const getWeather = async (city: string) => {
        try {
            const response = await fetch(`${base_url}?q=${city}&appid=${api_key}&units=metric`);
            const data = await response.json();
            setWeatherInfo({
                country: data.sys.country,
                city: data.name,
                temp: data.main.temp,
                pressure: data.main.pressure,
                sunset: data.sys.sunset
            });
            setMessage('');
        } catch (e) {
            setMessage('Enter correct city name');
        }
    }

    return (
        <div>
            <Form getWeather={getWeather} />
            <Weather info={weatherInfo} message={message} />
        </div>
    )
}

export default Data