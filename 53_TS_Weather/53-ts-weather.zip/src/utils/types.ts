export interface WeatherInfo {
    country?: string,
    city?: string,
    temp?: number,
    pressure?: number,
    sunset?: number
}