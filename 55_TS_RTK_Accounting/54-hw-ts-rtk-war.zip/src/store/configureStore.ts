import { configureStore } from "@reduxjs/toolkit";
import view from '../slices/viewSlice';
import gameWar from '../slices/gameWarSlice';
import { TypedUseSelectorHook, useDispatch, useSelector } from "react-redux";

// type state = {
//     view: {
//         name: string,
//         page: string
//     }, 
//     gameWar: {       
//         globalScore: [number, number, string]
//     }     
// }

export const store = configureStore({
    reducer: {
        view, gameWar
    }
})

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export const useAppDispatch: () => AppDispatch = useDispatch;
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;