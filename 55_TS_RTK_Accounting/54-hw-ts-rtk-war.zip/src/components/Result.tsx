import { changePage } from '../slices/viewSlice';
import { useAppDispatch, useAppSelector } from '../store/configureStore';
import { game } from '../utils/constants';

const Result = () => {
    const score = useAppSelector(state => state.gameWar.globalScore);
    const dispatch = useAppDispatch();

    return (
        <>
            <h1>{score[2]}</h1>
            <h2>{score[1]} - {score[0]}</h2>
            <button onClick={() => dispatch(changePage(game))}>Again?</button>
        </>
    )
}

export default Result