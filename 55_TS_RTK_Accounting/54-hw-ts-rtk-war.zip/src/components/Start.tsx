import { useState } from 'react';
import { changeName, changePage } from '../slices/viewSlice';
import { useAppDispatch } from '../store/configureStore';
import { game } from '../utils/constants';

const Start = () => {

    const dispatch = useAppDispatch();
    const [name, setName] = useState('');

    const handleClickStart = () => {
        dispatch(changePage(game));
        dispatch(changeName(name));
    }

    return (
        <>
            <h1>Ready For War</h1>
            <input
                onChange={e => setName(e.target.value.toUpperCase())}
                type='text'
                placeholder='Enter your name'
                value={name} />
            <button onClick={handleClickStart}>Start</button>
        </>
    )

}

export default Start