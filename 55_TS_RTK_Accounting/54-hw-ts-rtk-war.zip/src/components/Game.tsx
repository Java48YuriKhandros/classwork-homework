import { useEffect, useRef, useState } from 'react'
import { compWin, draw, playerWin } from '../slices/gameWarSlice'
import { changePage } from '../slices/viewSlice'
import { useAppDispatch, useAppSelector } from '../store/configureStore'
import { createDeck, result } from '../utils/constants'
import { Card } from '../utils/types'

const Game = () => {

    const name = useAppSelector(state => state.view.name);
    const dispatch = useAppDispatch();

    const compDeck = useRef<Card[]>([]);
    const playerDeck = useRef<Card[]>([]);

    const [compCard, setCompCard] = useState('Computer card');
    const [playerCard, setPlayerCard] = useState('Player card');
    const [playerRes, setPlayerRes] = useState(0);
    const [compRes, setCompRes] = useState(0);

    useEffect(() => {
        const deck = createDeck();
        for (let i = deck.length - 1; i > 0; i--) {
            let j = Math.floor(Math.random() * (i + 1));
            [deck[i], deck[j]] = [deck[j], deck[i]];
        }
        compDeck.current = deck.slice(0, 26);
        playerDeck.current = deck.slice(26, 52);
        return () => console.log("Game unmounted");
    }, [])


    const handleClickNext = () => {
        if (compDeck.current.length) {
            const player = playerDeck.current.pop() as Card;
            const comp = compDeck.current.pop() as Card;
            if (player.rank < comp.rank) {
                setCompRes(prevCompRes => prevCompRes + 1);
            }
            if (player.rank > comp.rank) {
                setPlayerRes(prevPlayerRes => prevPlayerRes + 1);
            }
            setCompCard(`${comp.rank} ${comp.suit}`)
            setPlayerCard(`${player.rank} ${player.suit}`)
        } else {
            if (playerRes > compRes) {
                dispatch(playerWin())
            }
            if (playerRes < compRes) {
                dispatch(compWin())
            }
            if (playerRes === compRes) {
                dispatch(draw())
            }
            dispatch(changePage(result));
        }
    }

    return (
        <>
            <h2>Computer ({compRes})</h2>
            <p>{compCard}</p>
            <p>{playerCard}</p>
            <h2>{name} ({playerRes})</h2>
            <button onClick={handleClickNext}>Next</button>
        </>
    )
}

export default Game