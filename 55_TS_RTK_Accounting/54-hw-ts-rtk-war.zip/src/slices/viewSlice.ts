import { createSlice } from "@reduxjs/toolkit";
import { start } from "../utils/constants";

const initialState = {
    name: 'YOU',
    page: start
}

const viewSlice = createSlice({
    name: 'view',
    initialState,
    reducers: {
        changeName(state, action) {
            state.name = action.payload || initialState.name;
        },
        changePage(state, action) {
            state.page = action.payload;
        }
    }
})

export const { changeName, changePage } = viewSlice.actions;
export default viewSlice.reducer;