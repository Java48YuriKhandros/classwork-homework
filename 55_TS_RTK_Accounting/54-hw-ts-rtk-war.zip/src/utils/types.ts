type Result = 'Win' | 'Lose' | 'Draw';

export interface GlobalScore {
    globalScore: [number, number, Result?]
}

export interface User {
    page: string,
    name: string
}

export type Suit = 'spade' | 'club' | 'diamond' | 'heart'

export interface Card {
    rank: number,
    suit: Suit
}