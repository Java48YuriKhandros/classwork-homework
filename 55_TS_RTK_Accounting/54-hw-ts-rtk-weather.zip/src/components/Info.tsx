
const Info = () => {
    return (
        <div>
            <h1>Weather application</h1>
            <p>Your city weather</p>
        </div>
    )
}

export default Info;