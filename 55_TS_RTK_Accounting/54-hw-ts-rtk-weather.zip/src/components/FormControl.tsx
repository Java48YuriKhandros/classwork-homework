import { ChangeEvent, useState } from 'react';
import { fetchWeather } from '../actions/actionFunctions';
import { useAppDispatch } from '../utils/hooks';

export const FormControl = () => {

    const [city, setCity] = useState('');
    const dispatch = useAppDispatch();

    const handleChangeCity = (e: ChangeEvent<HTMLInputElement>) => {
        setCity(e.target.value)
    }

    const handleClickGetWeather = () => {
        dispatch(fetchWeather(city));
        setCity('');
    }

    return (
        <div>
            <input onChange={handleChangeCity} type='text' value={city} />
            <button onClick={handleClickGetWeather} >Get weather</button>
        </div>
    )

}

export default FormControl