export interface WeatherInfo {
    country?: string,
    city?: string,
    temp?: number,
    pressure?: number,
    sunset?: number
}

export interface WeatherPayload {
    main: {
        temp: number,
        pressure: number
    },
    sys: {
        country: string,
        sunset: number
    }
    name: string
}