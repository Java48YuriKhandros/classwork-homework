import { configureStore } from "@reduxjs/toolkit";
import messageReducer from "../slices/messageSlice";
import weatherReducer from "../slices/weatherSlice";

// type state = {
//     weatherInfo: {
//         [key]: string|number
//     },
//     message: string
// }

export const store = configureStore({
    reducer: {
        weatherInfo: weatherReducer,
        message: messageReducer
    }
})

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;