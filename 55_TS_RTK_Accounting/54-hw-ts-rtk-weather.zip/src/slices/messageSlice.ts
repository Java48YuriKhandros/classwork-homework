import { createSlice } from "@reduxjs/toolkit";
import { fetchWeather } from "../actions/actionFunctions";

const messageSlice = createSlice({
    name: 'message',
    initialState: 'Enter city name',
    reducers: {
    },
    extraReducers: builder => {
        builder
        .addCase(fetchWeather.pending, state => {
            return 'Pending...';
        })
        .addCase(fetchWeather.fulfilled, state => {
            return '';
        })
        .addCase(fetchWeather.rejected, state => {
            return 'Enter correct city name';
        })
    }
})

export default messageSlice.reducer;