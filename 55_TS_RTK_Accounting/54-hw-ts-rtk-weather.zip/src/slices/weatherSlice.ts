import { createSlice } from "@reduxjs/toolkit";
import { fetchWeather } from '../actions/actionFunctions';
import { WeatherInfo } from "../utils/types";

const initialState: WeatherInfo = {}

const weatherSlice = createSlice({
    name: 'weather',
    initialState,
    reducers: {},
    extraReducers: builder => {
        builder.addCase(fetchWeather.fulfilled, (state, action) => {
            const data = action.payload;
            state.country = data.sys.country;
            state.city = data.name;
            state.temp = data.main.temp;
            state.pressure = data.main.pressure;
            state.sunset = data.sys.sunset;
        })
    }
})


export default weatherSlice.reducer;