import React from 'react'

const UpdateUser = () => {
  return (
    <div>UpdateUser</div>
  )
}

export default UpdateUser