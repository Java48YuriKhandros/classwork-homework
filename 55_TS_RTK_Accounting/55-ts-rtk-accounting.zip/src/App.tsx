import './App.css';
import Guest from './components/Guest';

function App() {
  return (
    <Guest/>
  );
}

export default App;
