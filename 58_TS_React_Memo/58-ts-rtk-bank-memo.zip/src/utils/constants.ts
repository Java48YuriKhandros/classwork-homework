export const names = ['Braavos', 'Riverlands', 'Westerlands', 'Crownlands'];
export const getRandomIndex = (bound: number) => Math.trunc(Math.random() * bound);
export const getBank = (index: number) => ({name: names[index]});