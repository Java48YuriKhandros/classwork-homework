import React, { useCallback, useMemo, useState } from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '../configureStore/store';
import accountReducer from '../reducers/accountReducer';
import quoteReducer from '../reducers/quoteReducer';
import { getBank, getRandomIndex, names } from '../utils/constants';
import Bank from './Bank';

const Balance = () => {
  console.log(`Render Balance`);
  const { balance } = useSelector<RootState, ReturnType<typeof accountReducer>>(state => state.account);
  const quote = useSelector<RootState, ReturnType<typeof quoteReducer>>(state => state.quote);
  // const info = 'Braavos'; //solution React.memo in Bank

  // const info = {name: 'Braavos'}; //solution React.memo in Bank, and useState or useMemo
  // const [info, setInfo] = useState({name: 'Braavos'});
  // const info = useMemo(() => ({ name: 'Braavos' }), []);

  const index = getRandomIndex(names.length);
  // const info = { name: names[index] }; //solution React.memo in Bank and useMemo
  // const info = useMemo(() => ({ name: names[index] }), [index]);
  // const getInfo = () => getBank(index); //solution React.memo in Bank and useCallback
  const getInfo = useCallback(() => getBank(index), [index]);

  return (
    <div>
      <Bank info={getInfo} />
      <h4 className='text-center text-uppercase'>{quote}</h4>
      <h3 className='text-center text-uppercase'>Balance = {balance}</h3>
    </div>
  )

}

export default Balance