import React from 'react'

interface Props {
    //info: {name: string}
    info: () => ({name: string})
}

const Bank = ({ info}: Props) => {
    //console.log(`Render bank ${info.name}`);
    console.log(`Render bank ${info().name}`);

    return (
        <h1 className='text-center text-uppercase'>Iron Bank of {info().name}</h1>
    )
}

export default React.memo(Bank);