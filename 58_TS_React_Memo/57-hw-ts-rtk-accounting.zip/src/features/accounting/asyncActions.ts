import { createAsyncThunk } from "@reduxjs/toolkit";
import { RootState } from "../../app/store";
import { base_url, createToken } from "../../utils/constants";
import { UserData, UserProfile, UserRegister, UserUpdatePass } from "../../utils/types";

export const registerUser = createAsyncThunk(
    'user/register',
    async (user: UserRegister) => {
        const response = await fetch(`${base_url}/user`, {
            method: 'Post',
            body: JSON.stringify(user),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        if (response.ok) {
            const data = await response.json();
            const token = createToken(user.login, user.password);
            return { data, token };
        }
        throw new Error(response.status.toString())
    }
)

export const fetchUser = createAsyncThunk(
    'user/login',
    async (token: string) => {
        const response = await fetch(`${base_url}/login`, {
            method: 'Post',
            headers: {
                Authorization: token
            }
        })
        if (response.ok) {
            const data = await response.json();
            return { data, token };
        }
        throw new Error(response.status.toString())
    }
)

export const updateUser = createAsyncThunk< UserProfile , UserData, { state: RootState }>(
    'user/update',
    async (user, { getState }) => {
        const response = await fetch(`${base_url}/user`, {
            method: 'Put',
            body: JSON.stringify(user),
            headers: {
                Authorization: getState().token!,
                'Content-Type': 'application/json'
            }
        })
        if (response.ok) {
            const data = await response.json();
            return  data ;
        }
        throw new Error(response.status.toString())
    }
)

export const changePassword = createAsyncThunk(
    'user/password',
    async (user: UserUpdatePass) => {
        const response = await fetch(`${base_url}/user/password`, {
            method: 'Put',
            headers: {
                Authorization: createToken(user.login, user.oldPassword),
                'X-Password': user.password
            }
        })
        if (response.ok) {
            return createToken(user.login, user.password);
        }
        throw new Error(response.status.toString())
    }
)