import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { UserProfile } from "../../utils/types";
import { fetchUser, registerUser, updateUser } from "./asyncActions";


const userSlice = createSlice({
    name: 'user',
    initialState: null as null | UserProfile,
    reducers: {
        putUser: (state, action: PayloadAction<UserProfile>) => action.payload,
        deleteUser: (state) => null,
        changeFirstName: (state, action: PayloadAction<string>) => {
            state!.firstName = action.payload;
        },
        changeLastName: (state, action: PayloadAction<string>) => {
            state!.lastName = action.payload;
        }
    },
    extraReducers: builder => {
        builder
            .addCase(registerUser.fulfilled, (state, action) => {
                return action.payload.data;
            })
            .addCase(fetchUser.fulfilled, (state, action) => {
                return action.payload.data;
            })
            .addCase(updateUser.fulfilled, (state, action) => {
                state!.firstName =action.payload.firstName;
                state!.lastName =action.payload.lastName;
            })
    }
})

export const { putUser, deleteUser, changeFirstName, changeLastName } = userSlice.actions;
export default userSlice.reducer;