
export interface UserData {
    firstName: string,
    lastName: string
}

interface User extends UserData{
    login: string
}

export interface UserProfile extends User {
    roles: string[]
}

export interface UserRegister extends User {
    password: string
}

export interface UserUpdatePass {
    login: string,
    password: string,
    oldPassword: string
}

export enum UpdateUserAction {
    editUser = 'editUser', changePassword = 'changePassword', default = ''
}
