import React, { useState } from 'react'
import { UpdateUserAction } from '../../utils/types';
import ChangePassword from './ChangePassword';
import EditUser from './EditUser';

const UpdateUser = () => {
  const [updateAction, setUpdateAction] = useState<UpdateUserAction>(UpdateUserAction.default)

  switch (updateAction) {
    case UpdateUserAction.editUser:
      return <EditUser close={() => setUpdateAction(UpdateUserAction.default)} />;
    case UpdateUserAction.changePassword:
      return <ChangePassword close={() => setUpdateAction(UpdateUserAction.default)} />;
    default:
      return (
        <div>
          <button onClick={() => setUpdateAction(UpdateUserAction.changePassword)}>Change password</button>
          <button onClick={() => setUpdateAction(UpdateUserAction.editUser)}>Edit user profile</button>
        </div>
      )
  }

}

export default UpdateUser