var i = -1;
const fn = () => {
    var i = 1;
    console.log(i);
}
fn();
//scope
console.log(i);